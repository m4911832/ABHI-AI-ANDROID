import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
app.use(cors());
app.use(express.json({ limit: "32kb" }));

const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) {
  console.error("Missing OPENAI_API_KEY. Copy .env.example to .env and add your key.");
  process.exit(1);
}

const client = new OpenAI({ apiKey });
const model = process.env.OPENAI_MODEL || "gpt-6.2-sol";

const assistantInstructions = `
You are ABHI AI, a capable, polite personal assistant for the user.
The user speaks Hindi and English. Reply in the language used by the user,
or follow an explicit language request. Use natural Indian English/Hindi.
Be practical, concise, and action-oriented.
You may help plan emails, schedules, reports, sales reviews, calculations,
and other work. Do not claim you have sent a message, made a call, changed
a file, booked anything, or controlled the phone unless a connected tool
actually completed that action. In this Version 1 chat build, you have no
external action tools. For actions with real-world consequences, prepare
the proposed content and clearly ask for confirmation before any future
integration executes it. Never ask for passwords or API keys in chat.
`;

app.get("/health", (_req, res) => res.json({ ok: true, service: "ABHI AI backend" }));

app.post("/chat", async (req, res) => {
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  const language = req.body?.language === "Hindi" ? "Hindi" : "English";
  if (!message) return res.status(400).json({ error: "message is required" });
  if (message.length > 8000) return res.status(413).json({ error: "message is too long" });

  try {
    const response = await client.responses.create({
      model,
      instructions: assistantInstructions + `\nPreferred interface language: ${language}.`,
      input: message
    });
    res.json({ reply: response.output_text || "I couldn't generate a reply. Please try again." });
  } catch (error) {
    console.error("OpenAI request failed:", error?.message || "unknown error");
    res.status(502).json({ error: "AI service request failed. Check the backend configuration and model access." });
  }
});

const port = Number(process.env.PORT || 8787);
app.listen(port, "0.0.0.0", () => {
  console.log(`ABHI AI backend listening on port ${port}`);
});
