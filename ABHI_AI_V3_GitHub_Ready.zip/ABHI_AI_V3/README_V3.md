# ABHI AI V3 — Android + Groq starter

This is an upgrade of the supplied V2 source, preserving the Kotlin/Compose app and approval repository.

## Included in this source update
- Groq Chat Completions backend (OpenAI-compatible Groq endpoint); API key stays on backend.
- Android chat language modes: Auto-detect, Hindi, English, Bhojpuri.
- Auto mode delegates speech-language choice to the installed Android speech provider.
- Bhojpuri speech input currently falls back to Hindi (`hi-IN`) because Bhojpuri recognition is not consistently exposed as a standard Android speech locale. Groq response prompting supports Bhojpuri text conversation.
- Animated holographic-style robot face in the Compose UI (visual prototype; speaking animation is approximate).
- V2 task proposal/approval classes copied into the app source package.
- HTTPS-only network policy by default; rate limiting and Helmet on backend.

## Not yet implemented / not to be advertised as working
- No live caller-ID database, spam scoring, automatic call screening, or call blocking.
- No real always-on "Hello Abhi" wake-word engine. `WakeWordEngine` remains an interface only.
- Approval records do not execute Gmail, WhatsApp, SMS, Calendar, or phone actions.
- No production user authentication or encrypted server-side user sessions yet.
- Speech recognition and Bhojpuri voice output depend on Android speech/TTS provider language support.

## Backend setup
1. Install Node.js 20+ on a host that can run a persistent Node service.
2. In `backend/`, run `npm install`.
3. Set `GROQ_API_KEY` in the host's secret/environment settings. Never commit `.env` or put the key in the APK.
4. Optionally set `GROQ_MODEL`; default is `llama-3.3-70b-versatile`.
5. Run `npm start`. Check `/health`.
6. Deploy behind HTTPS. The Android app rejects cleartext HTTP by default.

## Android build
Open `android/` in Android Studio (JDK 17, Android SDK 35). Set the backend URL at build time, for example:

`./gradlew assembleDebug -PBACKEND_BASE_URL=https://YOUR-HOST/`

The default backend URL is a placeholder (`https://YOUR-BACKEND-HOST/`). Set the GitHub repository variable `BACKEND_BASE_URL` to your deployed HTTPS backend URL before running the build workflow. A physical phone needs a reachable HTTPS backend.

## Important next steps before public release
- Add authenticated user sessions; rate limiting alone is not authentication.
- Add a privacy policy, consent screens, data retention controls, and secure audit history.
- Use encrypted local storage for approvals and bind approval to immutable proposal content.
- Implement and test each connector independently; require fresh confirmation for sends/calls/changes.
- Add a dedicated licensed on-device wake-word SDK and foreground service before enabling wake phrase.
- Caller screening requires Android role/CallScreeningService integration, user-granted role, a trusted spam data source, false-positive controls, and device testing. It cannot be promised as universally free or reliable.
- Test speech recognition and TTS on the target Motorola device, especially Bhojpuri.
