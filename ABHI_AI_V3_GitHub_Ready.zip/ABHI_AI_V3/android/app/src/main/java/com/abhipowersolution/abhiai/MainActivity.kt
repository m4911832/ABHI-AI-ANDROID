package com.abhipowersolution.abhiai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { AbhiAiScreen(onSpeak = { speak(it) }) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN")
    }

    private fun speak(text: String) {
        val locale = if (text.any { it in '\u0900'..'\u097F' }) Locale("hi", "IN") else Locale("en", "IN")
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "abhi-ai-response")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AbhiAiScreen(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var language by remember { mutableStateOf("Auto-detect") }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready when you are") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Namaste! Main ABHI AI hoon. Aap Hindi ya English mein baat kar sakte hain. How can I help?", false)
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startSpeech(context, language) { spoken -> input = spoken }
        else status = "Microphone permission is required for voice input."
    }

    fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            status = "Speech recognition is not available on this device."
            return
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startSpeech(context, language) { spoken -> input = spoken }
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    suspend fun sendMessage() {
        val prompt = input.trim()
        if (prompt.isEmpty() || busy) return
        messages.add(ChatMessage(prompt, true))
        input = ""
        busy = true
        status = "ABHI AI is thinking…"
        try {
            val answer = withContext(Dispatchers.IO) { callBackend(prompt, language) }
            messages.add(ChatMessage(answer, false))
            onSpeak(answer)
            status = "Response ready"
        } catch (e: Exception) {
            messages.add(ChatMessage("I couldn't connect to the ABHI AI server. Please check that the backend is running and the phone can reach it. Details: ${e.message ?: "Network error"}", false))
            status = "Connection problem"
        } finally {
            busy = false
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF8EA7FF),
            secondary = Color(0xFFB5A0FF),
            background = Color(0xFF090D18),
            surface = Color(0xFF151C2D)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFF090D18),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("ABHI AI", fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text("Your personal voice assistant", fontSize = 11.sp, color = Color.LightGray)
                        }
                    },
                    actions = {
                        var menuOpen by remember { mutableStateOf(false) }
                        TextButton(onClick = { menuOpen = true }) { Text(language) }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            listOf("Auto-detect", "Hindi", "English", "Bhojpuri").forEach { choice ->
                                DropdownMenuItem(text = { Text(choice) }, onClick = { language = choice; menuOpen = false })
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF10182A),
                        titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF10182A))
                        .padding(12.dp)
                ) {
                    Text(status, color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.padding(bottom = 7.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { listen() },
                            modifier = Modifier.size(52.dp).background(Color(0xFF293B68), CircleShape)
                        ) { Icon(Icons.Default.Mic, contentDescription = "Speak", tint = Color.White) }
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Type or tap mic…") },
                            maxLines = 3,
                            shape = RoundedCornerShape(18.dp)
                        )
                        IconButton(
                            onClick = { scope.launch { sendMessage() } },
                            enabled = !busy && input.isNotBlank(),
                            modifier = Modifier.size(52.dp).background(Color(0xFF435FC4), CircleShape)
                        ) { Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White) }
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFF111C36), Color(0xFF090D18))))
                    .padding(padding)
            ) {
                Box(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp), contentAlignment = Alignment.Center) {
                    HologramRobot(isSpeaking = busy)
                }
                Text("Hello! Ready to help.", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(messages) { message ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Surface(
                                color = if (message.fromUser) Color(0xFF334B91) else Color(0xFF1A263D),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.fillMaxWidth(0.88f)
                            ) {
                                Column(Modifier.padding(13.dp)) {
                                    Text(if (message.fromUser) "YOU" else "ABHI AI", color = Color(0xFFB9C8FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(4.dp))
                                    Text(message.text, color = Color.White, fontSize = 15.sp)
                                    if (!message.fromUser) {
                                        Spacer(Modifier.height(4.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(14.dp))
                                            Text(" Spoken response", color = Color.LightGray, fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (busy) item { CircularProgressIndicator(Modifier.padding(8.dp), color = Color(0xFF8EA7FF)) }
                }
            }
        }
    }
}

@Composable
private fun HologramRobot(isSpeaking: Boolean) {
    val infinite = rememberInfiniteTransition(label = "robot")
    val pulse by infinite.animateFloat(
        initialValue = 0.88f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(950), RepeatMode.Reverse), label = "pulse"
    )
    val eyeGlow = if (isSpeaking) Color(0xFF6CFFEF) else Color(0xFF75B8FF)
    Box(Modifier.size(132.dp).background(
        Brush.radialGradient(listOf(Color(0x66526FD9), Color(0x33252D68), Color.Transparent)), CircleShape
    ), contentAlignment = Alignment.Center) {
        Box(Modifier.size((88 * pulse).dp).background(
            Brush.radialGradient(listOf(Color(0xAA397DCC), Color(0xFF152D55))), RoundedCornerShape(34.dp)
        ), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Box(Modifier.size(13.dp, 17.dp).background(eyeGlow, CircleShape))
                    Box(Modifier.size(13.dp, 17.dp).background(eyeGlow, CircleShape))
                }
                Spacer(Modifier.height(12.dp))
                Box(Modifier.width(if (isSpeaking) 28.dp else 19.dp).height(if (isSpeaking) 9.dp else 4.dp)
                    .background(Color(0xFF8DEBFF), RoundedCornerShape(50)))
            }
        }
    }
}

private fun startSpeech(
    context: android.content.Context,
    language: String,
    onResult: (String) -> Unit
) {
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    recognizer.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { recognizer.destroy() }
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) onResult(text)
            recognizer.destroy()
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        if (language == "Hindi" || language == "Bhojpuri") {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
        } else if (language == "English") {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
        }
        // Android 14+ speech providers may use this hint to identify the spoken language.
        // Older providers may ignore it and use their configured default language.
        if (language == "Auto-detect") {
            putExtra("android.speech.extra.ENABLE_LANGUAGE_DETECTION", true)
        }
        // Bhojpuri currently uses Hindi recognition as a compatibility fallback.
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
    }
    recognizer.startListening(intent)
}

private fun callBackend(message: String, language: String): String {
    val url = URL(BuildConfig.BACKEND_BASE_URL + "chat")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 60000
        doOutput = true
        setRequestProperty("Content-Type", "application/json; charset=utf-8")
    }
    try {
        val payload = JSONObject()
            .put("message", message)
            .put("language", language)
        connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (connection.responseCode !in 200..299) {
            throw IllegalStateException("Server returned ${connection.responseCode}: $body")
        }
        return JSONObject(body).optString("reply", "I couldn't form a response.")
    } finally {
        connection.disconnect()
    }
}
