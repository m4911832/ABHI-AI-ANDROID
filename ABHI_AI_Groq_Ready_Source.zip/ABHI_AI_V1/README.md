# ABHI AI — Android Voice Assistant (Version 1)

A starter Android app with:
- Hindi / English voice input using Android SpeechRecognizer
- Spoken responses using Android TextToSpeech
- Chat UI
- Secure server-side OpenAI Responses API integration
- A backend system prompt tailored as a personal assistant

## What Version 1 does
This is a working voice-chat foundation. It can listen, transcribe, send a message to the backend, display the answer and speak it aloud.

**Not yet implemented:** Gmail sending, WhatsApp/SMS sending, phone-wide control, calendar actions, alarms/reminders, Excel editing, background wake-word listening, and autonomous multi-step workflows. These require separate Android permissions, service integrations and explicit approval flows. The app does not pretend to perform those actions yet.

## Architecture
- `android/` — Kotlin + Jetpack Compose app
- `backend/` — Node.js + Express API server
- The OpenAI API key is stored only on the backend. Never put it in the APK.

## Requirements
- Android Studio (recent stable version)
- JDK 17
- Android SDK Platform 35
- Node.js 20+
- An OpenAI API key with API billing enabled

## 1. Start the backend
```bash
cd backend
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY
npm install
npm start
```
The server listens on port 8787 by default.

For a local Android emulator, the app's default backend URL is `http://10.0.2.2:8787/`.
For a physical Android phone, change `BACKEND_BASE_URL` in `android/app/build.gradle` to your computer's LAN IP, e.g. `http://192.168.1.10:8787/`, and ensure both devices are on the same Wi-Fi. This HTTP setting is for local development only. Deploy the backend behind HTTPS before real-world use.

## 2. Open the Android project
Open the `android/` folder in Android Studio, let Gradle sync, then run the `app` configuration on an Android device or emulator.

If Android Studio asks to install SDK Platform 35, accept.

## 3. Test
1. Start the backend.
2. Run the Android app.
3. Choose Hindi or English.
4. Tap the microphone and grant microphone permission.
5. Speak; the recognized text appears in the message box.
6. Tap Send. ABHI AI's response appears and is spoken aloud.

## Security / production checklist
- Deploy backend with HTTPS.
- Add user authentication and rate limiting.
- Persist conversation history securely.
- Add consent screens and a privacy policy.
- Do not log personal messages or secrets.
- Add tool-specific approval cards before sending messages, creating events, or modifying files.
- Restrict tool actions to allow-listed operations.

## Version roadmap
### V1 — Voice conversation foundation
- [x] Hindi / English selector
- [x] Speech-to-text
- [x] Text-to-speech
- [x] AI chat through a secure backend
- [x] Configurable assistant persona

### V1.1 — Personal productivity
- Reminders and scheduled notifications
- Local task list and daily briefing
- Conversation history

### V1.2 — Work assistant
- Gmail search and draft creation, then send only after approval
- Calendar read/create/update, with confirmation
- Upload and analyse Excel / PDF files

### V2 — Phone and workflow automation
- Approved Android intents for calls, messages and app launching
- Multi-step task plans with a review/approve screen
- Optional foreground listening mode; no hidden always-on recording

## Important
This starter is source code, not a signed APK. An APK must be built in Android Studio. API usage may incur charges from OpenAI.
