# ABHI AI 2.0 — Development Stage

This package extends the V1 starter with the Version 2 architecture and Android-side task approval foundation.

## Confirmed product decisions
- Android app
- Hindi + English
- Assistant prepares work and asks before execution
- Desired wake phrase: "Hello Abhi"

## Included in this stage
- A typed task proposal model with explicit states: DRAFT, WAITING_FOR_APPROVAL, APPROVED, REJECTED, EXECUTED, FAILED.
- A local approval repository that stores proposals on-device.
- A wake-word engine interface defining the boundary for a dedicated wake-word SDK.
- A detailed integration plan for the wake phrase and task connectors.

## Important limitations
This package does **not** claim that wake-word listening or external task execution is already active. A reliable "Hello Abhi" feature requires a dedicated wake-word engine, its Android SDK, a licensed/authorized keyword model, a microphone foreground service, and testing across the target phone's Android version and battery policies. Android's ordinary speech-to-text recognizer is not a reliable always-on wake-word detector.

Likewise, approving a proposal is not the same as executing it. Gmail, Calendar, WhatsApp, SMS, calling, and file-editing actions must each be connected and tested separately. The approval repository records a user's decision; it does not send messages or modify external accounts.

## Integrate into V1
Copy `android-v2/ApprovalModels.kt` and `android-v2/ApprovalRepository.kt` into:
`android/app/src/main/java/com/abhipowersolution/abhiai/`

Copy `android-v2/WakeWordEngine.kt` into the same package. It is an interface only; implement it with a dedicated wake-word SDK before enabling a wake-word setting in the app.

## Recommended next engineering sequence
1. Integrate an approval inbox screen showing each proposed action, affected account, content/changes, and risk.
2. Require explicit approval for each action. Reject and edit must also be available.
3. Implement Gmail draft creation first; then add a separate Send action requiring a fresh confirmation.
4. Add Calendar read and event-draft creation; require confirmation before create/update/cancel.
5. Add Android foreground wake-word service using a dedicated engine and visible microphone notification.
6. Add a privacy screen with wake-word toggle, microphone indicator, data retention controls, and stop button.
7. Test Hindi/English speech, false wake-ups, battery use, lock-screen behavior, and Android OEM restrictions.

## Security rules
- Never embed an OpenAI API key in the APK.
- Never execute an action merely because an AI model proposed it.
- Bind approval to an immutable proposal ID and exact proposal content.
- If content changes after approval, invalidate approval and ask again.
- Show the user the exact recipient, message, calendar date/time, or file changes before execution.
- Keep audit history of proposal, approval/rejection, execution result, and timestamp.
