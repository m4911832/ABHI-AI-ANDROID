# ABHI AI - Groq backend deployment

## Important
- The Android app must use the public HTTPS backend URL, not `10.0.2.2`.
- Keep `GROQ_API_KEY` only in the hosting provider's secret/environment settings. Never put it in this ZIP, Android app, GitHub source, or chat.
- This version is a chat assistant with tap-to-speak input. The always-on "Hello Abhi" wake phrase and external app actions are not implemented.

## Deploy backend on Render
1. Push this updated project to GitHub.
2. In Render, create a new Web Service and connect the GitHub repository.
3. Set Root Directory to `ABHI_AI_V1/backend`.
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Add environment variable `GROQ_API_KEY` and paste the key directly into Render's secure field.
7. Add `GROQ_MODEL` = `openai/gpt-oss-20b`.
8. Deploy. Open `https://YOUR-SERVICE.onrender.com/health`; expected JSON: `{"ok":true,"service":"ABHI AI backend"}`.

## Connect Android app
After Render gives the real service URL, replace the placeholder in:
`ABHI_AI_V1/android/app/build.gradle.kts`
with the exact URL ending in `/`, e.g. `https://your-real-service.onrender.com/`.
Then rebuild the APK using the GitHub Actions workflow and install the new APK.
