package com.abhipowersolution.abhiai

/**
 * Adapter boundary for a dedicated on-device wake-word SDK.
 *
 * Do not implement this with an endless Android SpeechRecognizer loop:
 * SpeechRecognizer is designed for recognition sessions, not robust,
 * low-power, always-on keyword spotting.
 *
 * A production implementation should:
 * - Use a dedicated wake-word engine and authorized "Hello Abhi" keyword model.
 * - Run only after the user explicitly enables it.
 * - Use a foreground microphone service with a persistent notification.
 * - Process wake detection on-device; do not stream ambient audio to the cloud.
 * - Stop immediately when the user disables it or taps Stop.
 * - Handle microphone permission, battery optimization, lock screen and OEM limits.
 */
interface WakeWordEngine {
    fun start(onWakeWordDetected: () -> Unit, onError: (String) -> Unit)
    fun stop()
    fun isRunning(): Boolean
}
