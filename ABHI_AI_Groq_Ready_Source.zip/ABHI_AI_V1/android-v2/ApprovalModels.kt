package com.abhipowersolution.abhiai

/**
 * A proposed action is inert until a human approves the exact proposal.
 * Approval is not execution. A connector must separately execute an approved proposal.
 */
enum class ProposalStatus {
    DRAFT,
    WAITING_FOR_APPROVAL,
    APPROVED,
    REJECTED,
    EXECUTED,
    FAILED
}

enum class ProposalType {
    EMAIL_DRAFT,
    EMAIL_SEND,
    CALENDAR_CREATE,
    CALENDAR_UPDATE,
    CALENDAR_CANCEL,
    REMINDER_CREATE,
    PHONE_CALL,
    SMS_SEND,
    WHATSAPP_SEND,
    FILE_UPDATE,
    OTHER
}

data class TaskProposal(
    val id: String,
    val type: ProposalType,
    val title: String,
    val explanation: String,
    val preview: String,
    val target: String = "",
    val status: ProposalStatus = ProposalStatus.WAITING_FOR_APPROVAL,
    val createdAtEpochMs: Long = System.currentTimeMillis(),
    val approvedAtEpochMs: Long? = null,
    val executedAtEpochMs: Long? = null,
    val failureReason: String? = null
) {
    fun canApprove(): Boolean = status == ProposalStatus.WAITING_FOR_APPROVAL
    fun canExecute(): Boolean = status == ProposalStatus.APPROVED
}
