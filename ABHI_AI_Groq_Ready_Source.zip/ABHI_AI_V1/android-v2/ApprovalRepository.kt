package com.abhipowersolution.abhiai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Small local persistence layer for the V2 approval inbox.
 * This stores proposals and decisions only; it does not execute external actions.
 *
 * For production, migrate to Room + encrypted storage and add authenticated
 * server-side audit records for actions involving connected accounts.
 */
class ApprovalRepository(context: Context) {
    private val prefs = context.getSharedPreferences("abhi_ai_approvals", Context.MODE_PRIVATE)

    @Synchronized
    fun createDraft(
        type: ProposalType,
        title: String,
        explanation: String,
        preview: String,
        target: String = ""
    ): TaskProposal {
        val proposal = TaskProposal(
            id = UUID.randomUUID().toString(),
            type = type,
            title = title,
            explanation = explanation,
            preview = preview,
            target = target,
            status = ProposalStatus.WAITING_FOR_APPROVAL
        )
        save(proposal)
        return proposal
    }

    @Synchronized
    fun all(): List<TaskProposal> {
        val raw = prefs.getString("proposals", "[]") ?: "[]"
        val array = JSONArray(raw)
        return (0 until array.length()).mapNotNull { index ->
            runCatching { fromJson(array.getJSONObject(index)) }.getOrNull()
        }.sortedByDescending { it.createdAtEpochMs }
    }

    @Synchronized
    fun approve(id: String): TaskProposal? {
        val current = all().firstOrNull { it.id == id } ?: return null
        if (!current.canApprove()) return null
        return current.copy(
            status = ProposalStatus.APPROVED,
            approvedAtEpochMs = System.currentTimeMillis()
        ).also(::save)
    }

    @Synchronized
    fun reject(id: String): TaskProposal? {
        val current = all().firstOrNull { it.id == id } ?: return null
        if (!current.canApprove()) return null
        return current.copy(status = ProposalStatus.REJECTED).also(::save)
    }

    /**
     * Call only after a real connector has successfully completed the action.
     * Do not call this just because the user tapped Approve.
     */
    @Synchronized
    fun markExecuted(id: String): TaskProposal? {
        val current = all().firstOrNull { it.id == id } ?: return null
        if (!current.canExecute()) return null
        return current.copy(
            status = ProposalStatus.EXECUTED,
            executedAtEpochMs = System.currentTimeMillis()
        ).also(::save)
    }

    @Synchronized
    fun markFailed(id: String, reason: String): TaskProposal? {
        val current = all().firstOrNull { it.id == id } ?: return null
        if (!current.canExecute()) return null
        return current.copy(status = ProposalStatus.FAILED, failureReason = reason).also(::save)
    }

    @Synchronized
    fun invalidateApprovalIfContentChanged(id: String, updatedPreview: String): TaskProposal? {
        val current = all().firstOrNull { it.id == id } ?: return null
        val changed = current.preview != updatedPreview
        val updated = current.copy(
            preview = updatedPreview,
            status = if (changed) ProposalStatus.WAITING_FOR_APPROVAL else current.status,
            approvedAtEpochMs = if (changed) null else current.approvedAtEpochMs
        )
        save(updated)
        return updated
    }

    private fun save(proposal: TaskProposal) {
        val existing = all().filterNot { it.id == proposal.id }
        val updated = (existing + proposal).sortedByDescending { it.createdAtEpochMs }
        val array = JSONArray()
        updated.forEach { array.put(toJson(it)) }
        prefs.edit().putString("proposals", array.toString()).apply()
    }

    private fun toJson(p: TaskProposal) = JSONObject().apply {
        put("id", p.id)
        put("type", p.type.name)
        put("title", p.title)
        put("explanation", p.explanation)
        put("preview", p.preview)
        put("target", p.target)
        put("status", p.status.name)
        put("createdAtEpochMs", p.createdAtEpochMs)
        put("approvedAtEpochMs", p.approvedAtEpochMs ?: JSONObject.NULL)
        put("executedAtEpochMs", p.executedAtEpochMs ?: JSONObject.NULL)
        put("failureReason", p.failureReason ?: JSONObject.NULL)
    }

    private fun fromJson(o: JSONObject) = TaskProposal(
        id = o.getString("id"),
        type = ProposalType.valueOf(o.getString("type")),
        title = o.getString("title"),
        explanation = o.getString("explanation"),
        preview = o.getString("preview"),
        target = o.optString("target", ""),
        status = ProposalStatus.valueOf(o.getString("status")),
        createdAtEpochMs = o.optLong("createdAtEpochMs"),
        approvedAtEpochMs = o.takeIf { !it.isNull("approvedAtEpochMs") }?.optLong("approvedAtEpochMs"),
        executedAtEpochMs = o.takeIf { !it.isNull("executedAtEpochMs") }?.optLong("executedAtEpochMs"),
        failureReason = o.takeIf { !it.isNull("failureReason") }?.optString("failureReason")
    )
}
