package com.abhipowersolution.abhiai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.min

/** User-controlled, draggable ABHI AI companion overlay. */
class FloatingRobotService : Service() {
    companion object {
        const val ACTION_START = "com.abhipowersolution.abhiai.FLOATING_START"
        const val ACTION_STOP = "com.abhipowersolution.abhiai.FLOATING_STOP"
        private const val CHANNEL_ID = "abhi_ai_companion"
        private const val NOTIFICATION_ID = 7301
    }

    private lateinit var windowManager: WindowManager
    private var robotView: FloatingRobotView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { removeRobot(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            ACTION_START, null -> {
                startForeground(NOTIFICATION_ID, buildNotification())
                if (robotView == null) showRobot()
            }
        }
        return START_STICKY
    }

    private fun showRobot() {
        val view = FloatingRobotView(this) { stopSelf() }
        val params = WindowManager.LayoutParams(
            dp(104), dp(118),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18); y = dp(180)
        }
        view.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f; private var downY = 0f
            private var startX = 0; private var startY = 0
            private var moved = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; moved = false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) moved = true
                        params.x = startX + dx; params.y = startY + dy
                        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved && event.x > v.width * .68f && event.y < v.height * .32f) stopSelf()
                        return true
                    }
                }
                return true
            }
        })
        try { windowManager.addView(view, params); robotView = view; layoutParams = params } catch (_: Exception) { stopSelf() }
    }

    private fun removeRobot() {
        robotView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        robotView = null; layoutParams = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "ABHI AI floating companion", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("ABHI AI companion is active")
            .setContentText("Your floating robot is available. Tap the app to manage it.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true).build()
    }

    override fun onDestroy() { removeRobot(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}

private class FloatingRobotView(context: android.content.Context, private val onClose: () -> Unit) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val density = resources.displayMetrics.density
    private val tick = object : Runnable {
        override fun run() { phase += .12f; invalidate(); postDelayed(this, 45) }
    }

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null); post(tick) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w * .5f; val cy = h * .48f
        val bob = kotlin.math.sin(phase.toDouble()).toFloat() * 3.5f * density
        paint.color = Color.argb(65, 70, 150, 255); canvas.drawCircle(cx, cy + bob, min(w, h) * .47f, paint)
        paint.shader = android.graphics.RadialGradient(cx, cy + bob, w * .43f, intArrayOf(Color.rgb(75, 190, 255), Color.rgb(18, 43, 82)), null, android.graphics.Shader.TileMode.CLAMP)
        canvas.drawRoundRect(cx-w*.36f, cy-h*.30f+bob, cx+w*.36f, cy+h*.27f+bob, 24*density, 24*density, paint)
        paint.shader = null
        paint.color = Color.rgb(105, 245, 255)
        val blink = if (phase % 13f < .25f) .25f else 1f
        canvas.drawOval(cx-w*.22f, cy-h*.12f+bob, cx-w*.08f, cy-h*.12f+10*density*blink+bob, paint)
        canvas.drawOval(cx+w*.08f, cy-h*.12f+bob, cx+w*.22f, cy-h*.12f+10*density*blink+bob, paint)
        paint.color = Color.WHITE
        paint.strokeWidth = 3*density; paint.style = Paint.Style.STROKE
        val mouthW = (12 + kotlin.math.abs(kotlin.math.sin(phase.toDouble())).toFloat()*8)*density
        canvas.drawArc(cx-mouthW, cy+h*.03f+bob, cx+mouthW, cy+h*.18f+bob, 10f, 160f, false, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(220, 255, 255, 255); paint.textSize = 9*density; paint.textAlign = Paint.Align.CENTER
        canvas.drawText("ABHI AI", cx, h*.91f, paint)
        paint.color = Color.rgb(255, 100, 100); canvas.drawCircle(w*.86f, h*.12f, 9*density, paint)
        paint.color = Color.WHITE; paint.textSize = 12*density
        canvas.drawText("×", w*.86f, h*.12f+4*density, paint)
    }

    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
}
